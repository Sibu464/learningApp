package com.mvp.cybergi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CybergiApplicationTests {

	@Test
	void contextLoads() {
	}

}
