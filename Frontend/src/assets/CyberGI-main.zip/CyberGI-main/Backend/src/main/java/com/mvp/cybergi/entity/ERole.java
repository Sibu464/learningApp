package com.mvp.cybergi.entity;

public enum ERole {
    ROLE_TEST,
    ROLE_EMPLOYEE,
    ROLE_EMPLOYER,
    ROLE_ADMIN
}
