package com.mvp.cybergi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CybergiApplication {

	public static void main(String[] args) {
		SpringApplication.run(CybergiApplication.class, args);
	}

}
