package com.mvp.cybergi.security;public class MySecurityConfig {
}
