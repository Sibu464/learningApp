export interface CompletedModule {
    id: number;
    moduleName: string;
    isCompleted: boolean;
    
  }