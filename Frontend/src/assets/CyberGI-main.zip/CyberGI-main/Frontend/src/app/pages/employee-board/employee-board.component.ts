import { Component } from '@angular/core';

@Component({
  selector: 'app-employee-board',
  templateUrl: './employee-board.component.html',
  styleUrls: ['./employee-board.component.scss']
})
export class EmployeeBoardComponent {

}
