export const environment = {
    apiUrl: 'http://localhost:8080/api/v1/',
    moduleUrl:'http://localhost:8080/api/quiz/modules',
    usersUrl:'http://localhost:8080/api/v1/empusers',
    subModuleUrl:'http://localhost:8080/api/subscribed-modules',
    getSubModules:'http://localhost:8080/api/subscribed-modules/employer/'


};