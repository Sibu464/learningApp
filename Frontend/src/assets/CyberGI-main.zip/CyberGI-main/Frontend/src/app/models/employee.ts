export interface Employee{
username: any;
    email:string;
    name:string;
    id:number
}