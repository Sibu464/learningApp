import { Component } from '@angular/core';

@Component({
  selector: 'app-employer-board',
  templateUrl: './employer-board.component.html',
  styleUrls: ['./employer-board.component.scss']
})
export class EmployerBoardComponent {

}
