export class FileDetails {
    name!: string;
    filUri!: string;
}